import { o as __toESM } from "../_runtime.mjs";
import { Y as require_react, b as useRouter, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as adminLogin } from "./rsvp.functions-r1vaP7yQ.mjs";
import { i as TextField, n as Button, t as Alert } from "./ui-6J1SPnMg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-BC4ofhTy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminLogin() {
	const router = useRouter();
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [show, setShow] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		setPending(true);
		setError("");
		try {
			const result = await adminLogin({ data: {
				username,
				password
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			await router.navigate({ to: "/admin/painel" });
		} catch {
			setError("Não foi possível entrar agora. Tente de novo.");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "bg-navy px-5 py-6 text-paper",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-xs font-semibold tracking-widest text-gold uppercase",
						children: "BB Confraternização 2026"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-6 font-display text-4xl",
						children: "Área administrativa"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-paper/75",
						children: "Acesso exclusivo da organização."
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto -mt-6 max-w-md px-4 pb-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-5 rounded-2xl bg-card p-5 shadow-card sm:p-8",
				onSubmit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Usuário",
						name: "username",
						autoComplete: "username",
						autoCapitalize: "off",
						spellCheck: false,
						value: username,
						onChange: (event) => setUsername(event.target.value),
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Senha",
							name: "password",
							type: show ? "text" : "password",
							autoComplete: "current-password",
							value: password,
							onChange: (event) => setPassword(event.target.value),
							className: "pr-24",
							required: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "absolute top-9 right-3 text-xs font-semibold tracking-wide text-navy uppercase",
							onClick: () => setShow((value) => !value),
							children: show ? "Ocultar" : "Mostrar"
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { children: error }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: pending,
						className: "w-full",
						children: pending ? "Entrando…" : "Entrar"
					})
				]
			})
		})]
	});
}
var SplitComponent = AdminLogin;
//#endregion
export { SplitComponent as component };
