import { o as __toESM } from "../_runtime.mjs";
import { Y as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as submitRegistration, o as fetchOwn } from "./rsvp.functions-r1vaP7yQ.mjs";
import { i as TextField, n as Button, t as Alert } from "./ui-6J1SPnMg.mjs";
import { r as Route$2 } from "./router-DQJ5EO4o.mjs";
import { t as RsvpForm } from "./rsvp-form-BdnGjnfJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/corrigir-D3kqMAb_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CorrectPage({ initial, initialCode }) {
	const [code, setCode] = (0, import_react.useState)(initialCode);
	const [record, setRecord] = (0, import_react.useState)(initial);
	const [activeCode, setActiveCode] = (0, import_react.useState)(initialCode);
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)("");
	async function search(event) {
		event.preventDefault();
		setPending(true);
		setError("");
		setDone("");
		try {
			const result = await fetchOwn({ data: { code } });
			if (!result.ok) {
				setRecord(null);
				setError(result.error);
				return;
			}
			if (!result.rsvp) {
				setRecord(null);
				setError("Informe o código recebido ao confirmar.");
				return;
			}
			setRecord(result.rsvp);
			setActiveCode(result.code);
		} catch {
			setError("Não foi possível buscar agora. Tente de novo.");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-paper px-4 py-8 pb-28 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-xs font-semibold tracking-widest text-navy uppercase",
					children: "BB Confraternização 2026"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-4xl text-navy",
					children: "Corrigir resposta"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "O código abre somente o seu registro. Nenhuma outra confirmação fica visível."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 flex flex-col gap-4 rounded-2xl bg-card p-5 shadow-card",
					onSubmit: search,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Código de correção",
							name: "code",
							value: code,
							onChange: (event) => setCode(event.target.value.toUpperCase()),
							autoCapitalize: "characters",
							autoComplete: "off",
							placeholder: "XXXXX-XXXXX"
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { children: error }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: pending,
							children: pending ? "Buscando…" : "Buscar minha resposta"
						})
					]
				}),
				record ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-4 rounded-2xl bg-card p-5 shadow-card sm:p-8",
					children: [done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
							tone: "ok",
							children: done
						})
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RsvpForm, {
						initial: record,
						correctionCode: activeCode,
						submitLabel: "Confirmar resposta",
						onSubmit: async (value) => {
							const response = await submitRegistration({ data: {
								...value,
								correctionCode: activeCode
							} });
							if (response.ok) {
								setDone(response.message);
								setRecord(response.rsvp);
								setActiveCode(response.code);
							}
							return response;
						}
					}, `${record.id}-${record.updatedAt}`)]
				}) : null
			]
		})
	});
}
function Corrigir() {
	const data = Route$2.useLoaderData();
	const record = data.ok ? data.rsvp : null;
	const code = data.ok ? data.code : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CorrectPage, {
		initial: record,
		initialCode: code
	});
}
//#endregion
export { Corrigir as component };
