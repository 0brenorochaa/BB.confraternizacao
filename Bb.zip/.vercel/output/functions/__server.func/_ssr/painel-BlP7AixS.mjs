import { o as __toESM } from "../_runtime.mjs";
import { Y as require_react, b as useRouter, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as deleteRegistration, i as changePassword, l as updateRegistration, n as adminLogout } from "./rsvp.functions-r1vaP7yQ.mjs";
import { a as cn, i as TextField, n as Button, t as Alert } from "./ui-6J1SPnMg.mjs";
import { c as LogOut, l as FileText, o as Search, r as Trash2, s as Pencil, u as Download } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-DQJ5EO4o.mjs";
import { a as formatWhen, i as displayRelation, o as normalizeName } from "./rsvp-model-PNZCC2kM.mjs";
import { t as RsvpForm } from "./rsvp-form-BdnGjnfJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/painel-BlP7AixS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "all",
		label: "Todos"
	},
	{
		id: "yes",
		label: "Confirmados"
	},
	{
		id: "no",
		label: "Não vão"
	},
	{
		id: "with",
		label: "Com acompanhante"
	},
	{
		id: "without",
		label: "Sem acompanhante"
	}
];
function AdminPanel({ username, stats, rows }) {
	const router = useRouter();
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [removing, setRemoving] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const visible = (0, import_react.useMemo)(() => {
		const needle = normalizeName(query);
		return rows.filter((row) => {
			if (!matchesFilter(row, filter)) return false;
			if (!needle) return true;
			const relation = displayRelation(row.companionRelation, row.companionRelationNote);
			return normalizeName(row.fullName).includes(needle) || normalizeName(row.companionName).includes(needle) || normalizeName(relation).includes(needle);
		});
	}, [
		rows,
		query,
		filter
	]);
	async function exportReport(kind) {
		const { downloadReport } = await import("./report-DoLRxrCJ.mjs");
		downloadReport(kind, rows, stats);
	}
	async function refresh() {
		await router.invalidate();
	}
	async function signOut() {
		await adminLogout();
		await router.navigate({ to: "/admin" });
	}
	async function confirmDelete() {
		if (!removing) return;
		setBusy(true);
		setError("");
		try {
			const result = await deleteRegistration({ data: { id: removing.id } });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setRemoving(null);
			setNotice("Registro excluído.");
			await refresh();
		} catch {
			setError("Não foi possível excluir agora.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper pb-28 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "bg-navy text-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-gold uppercase",
						children: "Organização"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-2xl sm:text-3xl",
						children: "BB Confraternização 2026"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void signOut(),
						className: "inline-flex h-11 items-center gap-2 rounded-full px-3 text-xs font-semibold tracking-wide text-gold uppercase",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Sair"]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex max-w-6xl flex-col gap-5 px-4 py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Sessão de ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-ink",
								children: username
							}),
							". Os números vêm dos registros salvos."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid grid-cols-2 gap-3 md:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Cadastrados",
								value: stats.registered,
								hint: "Respostas recebidas"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Vão participar",
								value: stats.attending,
								hint: "Participantes confirmados"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Não vão",
								value: stats.absent,
								hint: "Ausências registradas"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Acompanhantes",
								value: stats.companions,
								hint: "Somente de quem vai"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "col-span-2 rounded-2xl bg-navy p-5 text-paper shadow-card md:col-span-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold tracking-widest text-gold uppercase",
										children: "Total geral de pessoas confirmadas"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-display text-5xl tabular-nums",
										children: stats.confirmedPeople
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-paper/75",
										children: "Quem confirmou presença, já com os acompanhantes."
									})
								]
							})
						]
					}),
					notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
						tone: "ok",
						children: notice
					}) : null,
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { children: error }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl bg-card p-4 shadow-card sm:p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative w-full sm:max-w-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
										className: "pointer-events-none absolute top-10 left-3 size-4 text-muted",
										"aria-hidden": "true"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
										label: "Pesquisar por nome",
										name: "search",
										value: query,
										onChange: (event) => setQuery(event.target.value),
										placeholder: "Participante ou acompanhante",
										className: "pl-9"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "quiet",
										className: "h-11 px-4",
										onClick: () => void exportReport("pdf"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
											className: "size-4",
											"aria-hidden": "true"
										}), "PDF"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "quiet",
										className: "h-11 px-4",
										onClick: () => void exportReport("xlsx"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
											className: "size-4",
											"aria-hidden": "true"
										}), "Excel"]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-muted",
								children: "A exportação inclui todos os registros e os totais gerais."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 flex flex-wrap gap-2",
								children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": filter === item.id,
									onClick: () => setFilter(item.id),
									className: cn("h-11 rounded-full px-4 text-sm font-semibold", filter === item.id ? "bg-navy text-paper" : "bg-paper text-navy"),
									children: item.label
								}, item.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-sm text-muted tabular-nums",
								children: [visible.length, " nesta visão"]
							}),
							visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 rounded-xl bg-paper px-4 py-8 text-center text-sm text-muted",
								children: "Nenhum participante encontrado."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 flex flex-col gap-3 md:hidden",
								children: visible.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-xl bg-paper p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonBody, { row }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "quiet",
											className: "h-11 flex-1",
											onClick: () => setEditing(row),
											children: "Editar"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "quiet",
											className: "h-11 flex-1",
											onClick: () => setRemoving(row),
											children: "Excluir"
										})]
									})]
								}, row.id))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 hidden overflow-x-auto md:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full min-w-3xl text-left text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "text-xs tracking-wide text-muted uppercase",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "border-b border-line",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-3 pr-3 font-semibold",
													children: "Participante"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-3 pr-3 font-semibold",
													children: "Situação"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-3 pr-3 font-semibold",
													children: "Acompanhante"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-3 pr-3 font-semibold",
													children: "Nome"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-3 pr-3 font-semibold",
													children: "Parentesco"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-3 pr-3 font-semibold",
													children: "Data"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-3 pr-3 font-semibold",
													children: "Hora"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-3 font-semibold",
													children: "Ações"
												})
											]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: visible.map((row) => {
										const when = formatWhen(row.createdAt);
										const withCompanion = row.attending && row.hasCompanion;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "border-b border-line align-top",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 pr-3 font-medium",
													children: row.fullName
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 pr-3",
													children: row.attending ? "Vai" : "Não vai"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 pr-3",
													children: withCompanion ? "Sim" : "Não"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 pr-3",
													children: withCompanion ? row.companionName : "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 pr-3",
													children: withCompanion ? displayRelation(row.companionRelation, row.companionRelationNote) : "—"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 pr-3 tabular-nums",
													children: when.date
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-3 pr-3 tabular-nums",
													children: when.time
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															className: "grid size-11 place-items-center rounded-full text-navy",
															"aria-label": `Editar ${row.fullName}`,
															onClick: () => setEditing(row),
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															className: "grid size-11 place-items-center rounded-full text-navy",
															"aria-label": `Excluir ${row.fullName}`,
															onClick: () => setRemoving(row),
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
														})]
													})
												})
											]
										}, row.id);
									}) })]
								})
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordCard, {
						onDone: (message) => {
							setError("");
							setNotice(message);
						},
						onError: (message) => {
							setNotice("");
							setError(message);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "font-semibold text-navy underline decoration-gold underline-offset-4",
							children: "Voltar à página pública"
						})
					})
				]
			}),
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex items-end justify-center bg-navy/70 p-3 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "edit-title",
					className: "max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-card p-5 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "edit-title",
							className: "font-display text-2xl text-navy",
							children: editing.fullName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								"Confirmado em ",
								formatWhen(editing.createdAt).date,
								" às ",
								formatWhen(editing.createdAt).time,
								".",
								editing.updatedAt !== editing.createdAt ? ` Atualizado em ${formatWhen(editing.updatedAt).date} às ${formatWhen(editing.updatedAt).time}.` : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RsvpForm, {
								initial: editing,
								submitLabel: "Salvar alterações",
								onSubmit: async (value) => {
									const result = await updateRegistration({ data: {
										id: editing.id,
										...value
									} });
									if (result.ok) {
										setEditing(null);
										setNotice("Registro atualizado.");
										await refresh();
									}
									return result;
								}
							}, editing.updatedAt)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							className: "mt-3 w-full",
							onClick: () => setEditing(null),
							children: "Fechar"
						})
					]
				})
			}) : null,
			removing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex items-end justify-center bg-navy/70 p-3 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "delete-title",
					className: "w-full max-w-md rounded-2xl bg-card p-5 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "delete-title",
							className: "font-display text-2xl text-navy",
							children: "Excluir registro?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								"A confirmação de ",
								removing.fullName,
								" será apagada. Esta ação não pode ser desfeita."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-col gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => void confirmDelete(),
								disabled: busy,
								children: busy ? "Excluindo…" : "Excluir registro"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "quiet",
								onClick: () => setRemoving(null),
								disabled: busy,
								children: "Cancelar"
							})]
						})
					]
				})
			}) : null
		]
	});
}
function matchesFilter(row, filter) {
	if (filter === "yes") return row.attending;
	if (filter === "no") return !row.attending;
	if (filter === "with") return row.attending && row.hasCompanion;
	if (filter === "without") return !(row.attending && row.hasCompanion);
	return true;
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl bg-card p-4 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-wide text-muted uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-4xl text-navy tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: hint
			})
		]
	});
}
function PersonBody({ row }) {
	const when = formatWhen(row.createdAt);
	const withCompanion = row.attending && row.hasCompanion;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-semibold",
			children: row.fullName
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted",
			children: [
				row.attending ? "Vai participar" : "Não vai participar",
				" · ",
				when.date,
				" às ",
				when.time
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm",
			children: withCompanion ? `Acompanhante: ${row.companionName} · ${displayRelation(row.companionRelation, row.companionRelationNote)}` : "Sem acompanhante"
		})
	] });
}
function PasswordCard({ onDone, onError }) {
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [nextPassword, setNextPassword] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		if (nextPassword !== confirm) {
			onError("A confirmação da nova senha não confere.");
			return;
		}
		setPending(true);
		try {
			const result = await changePassword({ data: {
				currentPassword,
				nextPassword
			} });
			if (!result.ok) {
				onError(result.error);
				return;
			}
			setCurrentPassword("");
			setNextPassword("");
			setConfirm("");
			onDone("Senha alterada. A senha anterior não funciona mais.");
		} catch {
			onError("Não foi possível alterar a senha.");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-card p-5 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-navy",
				children: "Alterar senha"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "A senha é guardada apenas como hash. Use pelo menos 8 caracteres."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 grid gap-4 sm:grid-cols-3",
				onSubmit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Senha atual",
						name: "currentPassword",
						type: "password",
						autoComplete: "current-password",
						value: currentPassword,
						onChange: (event) => setCurrentPassword(event.target.value),
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Nova senha",
						name: "nextPassword",
						type: "password",
						autoComplete: "new-password",
						value: nextPassword,
						onChange: (event) => setNextPassword(event.target.value),
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "Confirmar nova senha",
						name: "confirmPassword",
						type: "password",
						autoComplete: "new-password",
						value: confirm,
						onChange: (event) => setConfirm(event.target.value),
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: pending,
						className: "sm:col-span-3",
						children: pending ? "Salvando…" : "Atualizar senha"
					})
				]
			})
		]
	});
}
function Painel() {
	const data = Route.useLoaderData();
	if (!data.ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-paper px-6 text-center text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: data.error })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, {
		username: data.username,
		stats: data.stats,
		rows: data.rows
	});
}
//#endregion
export { Painel as component };
