import { o as __toESM } from "../_runtime.mjs";
import { Y as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as submitRegistration } from "./rsvp.functions-r1vaP7yQ.mjs";
import { n as Button } from "./ui-6J1SPnMg.mjs";
import { a as ShieldCheck, i as Sparkles, t as Users } from "../_libs/lucide-react.mjs";
import { i as Route$3 } from "./router-DQJ5EO4o.mjs";
import { a as formatWhen } from "./rsvp-model-PNZCC2kM.mjs";
import { t as RsvpForm } from "./rsvp-form-BdnGjnfJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BqDewKwy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HomePage({ own, code }) {
	const [result, setResult] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [fresh, setFresh] = (0, import_react.useState)(false);
	const saved = result?.rsvp ?? null;
	const activeCode = result?.code || code;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "bg-navy text-paper",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-xl items-center justify-between gap-4 px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg tracking-wide",
					children: "BB 2026"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/admin",
					className: "text-xs font-semibold tracking-widest text-gold uppercase",
					children: "Área administrativa"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-xl px-5 pt-6 pb-24 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rise mx-auto mb-6 grid size-20 place-items-center rounded-full border border-gold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-3xl text-gold",
							children: "BB"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rise rise-2 text-xs font-semibold tracking-widest text-gold uppercase",
						children: "Celebração"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "rise rise-2 mt-3 font-display text-4xl leading-tight text-paper sm:text-5xl",
						children: "BB Confraternização 2026"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rise rise-3 mx-auto mt-4 max-w-md text-base text-paper/80",
						children: "Que bom receber você. Confirme sua presença para organizarmos a festa com cuidado — leva menos de um minuto."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "gold",
						className: "rise rise-3 mt-8",
						onClick: () => document.getElementById("confirmar")?.scrollIntoView({ behavior: "smooth" }),
						children: "Confirmar presença"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto -mt-12 max-w-xl px-4 pb-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "confirmar",
					className: "scroll-mt-6 rounded-2xl bg-card p-5 shadow-card sm:p-8",
					children: saved && !editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuccessPanel, {
						message: result?.message ?? "",
						code: result?.code ?? "",
						record: saved,
						onEdit: () => setEditing(true)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6 flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
								className: "mt-1 size-5 shrink-0 text-gold",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl text-navy",
								children: "Sua confirmação"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "A lista de participantes fica só com a organização. Você não vê os dados de outras pessoas."
							})] })]
						}),
						own && !fresh && !result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6 rounded-xl bg-paper px-4 py-3 text-sm text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								"Neste aparelho já existe uma resposta de ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: own.fullName }),
								". Você pode atualizá-la abaixo."
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-2 text-sm font-semibold text-navy underline decoration-gold underline-offset-4",
								onClick: () => setFresh(true),
								children: "Não sou esta pessoa — nova confirmação"
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RsvpForm, {
							initial: fresh ? null : own,
							correctionCode: fresh ? "" : activeCode,
							submitLabel: "Confirmar resposta",
							onSubmit: async (value) => {
								const response = await submitRegistration({ data: {
									...value,
									correctionCode: fresh ? "" : activeCode || value.correctionCode
								} });
								if (response.ok) {
									setResult(response);
									setEditing(false);
									setFresh(false);
								}
								return response;
							}
						}, fresh ? "fresh" : own?.id ?? "new")
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8 grid gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" }),
							title: "Acompanhante",
							text: "Se for levar alguém, o nome e o parentesco entram na conta."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5" }),
							title: "Correção",
							text: "Depois de enviar, você recebe um código para ajustar só a sua resposta."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" }),
							title: "Privacidade",
							text: "Uso exclusivo da confraternização, em respeito à LGPD."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "mt-10 text-center text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "BB Confraternização 2026" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/corrigir",
						className: "mt-2 inline-block font-semibold text-navy underline decoration-gold underline-offset-4",
						children: "Corrigir uma resposta já enviada"
					})]
				})
			]
		})]
	});
}
function Note({ icon, title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl bg-card p-4 shadow-field",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-gold",
				"aria-hidden": "true",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-display text-lg text-navy",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: text
			})
		]
	});
}
function SuccessPanel({ message, code, record, onEdit }) {
	const when = formatWhen(record.createdAt);
	const [copied, setCopied] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl text-navy",
				children: message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					record.attending ? "Presença confirmada" : "Ausência registrada",
					" para ",
					record.fullName,
					". Registro de ",
					when.date,
					" às ",
					when.time,
					", horário de Brasília."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-gold bg-paper px-4 py-4 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-muted uppercase",
						children: "Código de correção"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl tracking-widest text-navy",
						children: code
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-3 text-sm font-semibold text-navy underline decoration-gold underline-offset-4",
						onClick: async () => {
							try {
								await navigator.clipboard.writeText(code);
								setCopied(true);
							} catch {
								setCopied(false);
							}
						},
						children: copied ? "Código copiado" : "Copiar código"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Guarde este código. Com ele você corrige a sua resposta sem ver nem alterar o registro de outra pessoa. Se perder o código, a organização pode ajustar no painel."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: onEdit,
					children: "Corrigir esta resposta"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/corrigir",
					className: "text-center text-sm font-semibold text-navy underline decoration-gold underline-offset-4",
					children: "Usar o código em outro momento"
				})]
			})
		]
	});
}
function Home() {
	const own = Route$3.useLoaderData();
	if (!own.ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-paper px-6 text-center text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: own.error })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {
		own: own.rsvp,
		code: own.code
	});
}
//#endregion
export { Home as component };
