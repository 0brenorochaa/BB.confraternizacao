import { o as __toESM } from "../_runtime.mjs";
import { Y as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as cn, i as TextField, n as Button, r as SelectField, t as Alert } from "./ui-6J1SPnMg.mjs";
import { d as Check } from "../_libs/lucide-react.mjs";
import { s as validateRsvp, t as RELATIONS } from "./rsvp-model-PNZCC2kM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rsvp-form-BdnGjnfJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RsvpForm({ initial, correctionCode = "", submitLabel, onSubmit }) {
	const [fullName, setFullName] = (0, import_react.useState)(initial?.fullName ?? "");
	const [attending, setAttending] = (0, import_react.useState)(initial ? initial.attending : null);
	const [companion, setCompanion] = (0, import_react.useState)(initial && initial.attending ? initial.hasCompanion : null);
	const [companionName, setCompanionName] = (0, import_react.useState)(initial?.companionName ?? "");
	const [relation, setRelation] = (0, import_react.useState)(initial?.companionRelation ?? "");
	const [relationNote, setRelationNote] = (0, import_react.useState)(initial?.companionRelationNote ?? "");
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const showCompanion = attending === true;
	const showCompanionFields = attending === true && companion === true;
	async function handleSubmit(event) {
		event.preventDefault();
		if (attending === null) {
			setError("Informe se você vai participar.");
			return;
		}
		if (attending && companion === null) {
			setError("Informe se você vai levar um acompanhante.");
			return;
		}
		const parsed = validateRsvp({
			fullName,
			attending,
			hasCompanion: attending ? companion === true : false,
			companionName,
			companionRelation: relation,
			companionRelationNote: relationNote,
			correctionCode
		});
		if (!parsed.ok) {
			setError(parsed.error);
			return;
		}
		setError("");
		setPending(true);
		try {
			const result = await onSubmit(parsed.value);
			if (!result.ok) setError(result.error);
		} catch {
			setError("Não foi possível registrar agora. Tente de novo em instantes.");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "flex flex-col gap-6",
		onSubmit: handleSubmit,
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				label: "Nome completo",
				name: "fullName",
				autoComplete: "name",
				value: fullName,
				onChange: (event) => setFullName(event.target.value),
				placeholder: "Como está no documento",
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-sm font-medium text-ink",
						children: "Você vai participar da BB Confraternização 2026?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceButton, {
						selected: attending === true,
						onSelect: () => setAttending(true),
						label: "Sim, vou participar."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceButton, {
						selected: attending === false,
						onSelect: () => setAttending(false),
						label: "Não vou participar."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "reveal",
				"data-open": showCompanion ? "true" : "false",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "flex flex-col gap-3 pb-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm font-medium text-ink",
							children: "Você vai levar algum acompanhante?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceButton, {
							selected: companion === true,
							onSelect: () => setCompanion(true),
							label: "Sim."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceButton, {
							selected: companion === false,
							onSelect: () => setCompanion(false),
							label: "Não."
						})
					]
				}) })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "reveal",
				"data-open": showCompanionFields ? "true" : "false",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 pb-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							label: "Nome completo do acompanhante",
							name: "companionName",
							autoComplete: "off",
							value: companionName,
							onChange: (event) => setCompanionName(event.target.value),
							required: showCompanionFields
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectField, {
							label: "Qual é o parentesco ou relação com você?",
							name: "companionRelation",
							value: relation,
							onChange: (event) => setRelation(event.target.value),
							required: showCompanionFields,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Selecione"
							}), RELATIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: item
							}, item))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "reveal",
							"data-open": relation === "Outro" ? "true" : "false",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								label: "Escreva o parentesco",
								name: "companionRelationNote",
								value: relationNote,
								onChange: (event) => setRelationNote(event.target.value),
								placeholder: "Ex.: primo, colega, sogra"
							}) })
						})
					]
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { children: error }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				variant: "primary",
				disabled: pending,
				className: "w-full",
				children: pending ? "Registrando…" : submitLabel
			})
		]
	});
}
function ChoiceButton({ selected, onSelect, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": selected,
		onClick: onSelect,
		className: cn("flex min-h-12 w-full items-center justify-between gap-3 rounded-xl px-4 text-left text-sm font-semibold transition-transform duration-150 ease-out active:scale-[0.96]", selected ? "bg-navy text-paper" : "bg-card text-ink shadow-field"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "uppercase tracking-wide",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("grid size-5 shrink-0 place-items-center rounded-full border", selected ? "border-gold bg-gold text-navy" : "border-line bg-card"),
			"aria-hidden": "true",
			children: selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: "size-3.5",
				strokeWidth: 2.5
			}) : null
		})]
	});
}
//#endregion
export { RsvpForm as t };
