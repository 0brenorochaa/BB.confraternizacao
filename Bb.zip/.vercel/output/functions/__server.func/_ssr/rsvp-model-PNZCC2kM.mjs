//#region node_modules/.nitro/vite/services/ssr/assets/rsvp-model-PNZCC2kM.js
var RELATIONS = [
	"Amigo(a)",
	"Marido",
	"Esposa",
	"Namorado(a)",
	"Namorada",
	"Mãe",
	"Pai",
	"Filho(a)",
	"Filha",
	"Irmão",
	"Irmã",
	"Outro familiar",
	"Outro"
];
var SUCCESS_MESSAGE = "Sua resposta foi registrada com sucesso! Agradecemos sua participação na BB Confraternização 2026!";
var NAME_PATTERN = /^[\p{L}\s'.’-]+$/u;
function tidyName(name) {
	return name.replace(/\s+/g, " ").trim();
}
function normalizeName(name) {
	return name.normalize("NFD").replace(/\p{M}/gu, "").replace(/[-'`’]/g, " ").toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, "").replace(/\s+/g, " ").trim();
}
function hasFullName(name) {
	const parts = tidyName(name).split(" ").filter(Boolean);
	return parts.length >= 2 && parts.every((part) => /\p{L}/u.test(part));
}
function displayRelation(relation, note) {
	if (!relation) return "";
	if (relation === "Outro" && note.trim()) return note.trim();
	return relation;
}
function validateRsvp(raw) {
	const fullName = tidyName(raw.fullName ?? "");
	if (!fullName) return {
		ok: false,
		error: "Informe o nome completo."
	};
	if (fullName.length > 120) return {
		ok: false,
		error: "O nome está longo demais."
	};
	if (!NAME_PATTERN.test(fullName) || !hasFullName(fullName)) return {
		ok: false,
		error: "Informe nome e sobrenome, usando apenas letras."
	};
	const attending = raw.attending === true;
	let hasCompanion = raw.hasCompanion === true;
	let companionName = tidyName(raw.companionName ?? "");
	let companionRelation = (raw.companionRelation ?? "").trim();
	let companionRelationNote = tidyName(raw.companionRelationNote ?? "");
	if (!attending) {
		hasCompanion = false;
		companionName = "";
		companionRelation = "";
		companionRelationNote = "";
	} else if (!hasCompanion) {
		companionName = "";
		companionRelation = "";
		companionRelationNote = "";
	} else {
		if (!companionName) return {
			ok: false,
			error: "Informe o nome completo do acompanhante."
		};
		if (companionName.length > 120) return {
			ok: false,
			error: "O nome do acompanhante está longo demais."
		};
		if (!NAME_PATTERN.test(companionName) || !hasFullName(companionName)) return {
			ok: false,
			error: "Informe nome e sobrenome do acompanhante, usando apenas letras."
		};
		if (!RELATIONS.includes(companionRelation)) return {
			ok: false,
			error: "Selecione o parentesco do acompanhante."
		};
		if (companionRelation === "Outro") {
			if (companionRelationNote.length < 2) return {
				ok: false,
				error: "Escreva qual é o parentesco."
			};
			if (companionRelationNote.length > 80) return {
				ok: false,
				error: "O parentesco está longo demais."
			};
		} else companionRelationNote = "";
	}
	return {
		ok: true,
		value: {
			fullName,
			attending,
			hasCompanion,
			companionName,
			companionRelation,
			companionRelationNote,
			correctionCode: (raw.correctionCode ?? "").trim()
		}
	};
}
function formatWhen(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return {
		date: "—",
		time: "—"
	};
	return {
		date: new Intl.DateTimeFormat("pt-BR", {
			timeZone: "America/Sao_Paulo",
			day: "2-digit",
			month: "2-digit",
			year: "numeric"
		}).format(date),
		time: new Intl.DateTimeFormat("pt-BR", {
			timeZone: "America/Sao_Paulo",
			hour: "2-digit",
			minute: "2-digit",
			hourCycle: "h23"
		}).format(date)
	};
}
function coerceInput(data) {
	const record = data && typeof data === "object" ? data : {};
	const str = (key) => typeof record[key] === "string" ? record[key] : "";
	return {
		fullName: str("fullName"),
		attending: record.attending === true,
		hasCompanion: record.hasCompanion === true,
		companionName: str("companionName"),
		companionRelation: str("companionRelation"),
		companionRelationNote: str("companionRelationNote"),
		correctionCode: str("correctionCode")
	};
}
//#endregion
export { formatWhen as a, displayRelation as i, SUCCESS_MESSAGE as n, normalizeName as o, coerceInput as r, validateRsvp as s, RELATIONS as t };
