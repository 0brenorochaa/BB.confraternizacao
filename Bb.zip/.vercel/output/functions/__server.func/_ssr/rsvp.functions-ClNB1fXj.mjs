import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rsvp.functions-ClNB1fXj.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var submitRegistration_createServerFn_handler = createServerRpc({
	id: "3b15b66090a2feafa93c584cff65bbc98e5e56dc7c0960ad1bbe5ca6283f3816",
	name: "submitRegistration",
	filename: "src/lib/rsvp.functions.ts"
}, (opts) => submitRegistration.__executeServer(opts));
var submitRegistration = createServerFn({ method: "POST" }).inputValidator((data) => data).handler(submitRegistration_createServerFn_handler, async ({ data }) => {
	const { submitRegistration: submit } = await import("./rsvp.server-CeiC8-tp.mjs");
	return submit(data);
});
var fetchOwn_createServerFn_handler = createServerRpc({
	id: "efc40a0d76a9ee4373c9f666df4dd82b1e2aecc5df597bcd4ae70b499cca0c21",
	name: "fetchOwn",
	filename: "src/lib/rsvp.functions.ts"
}, (opts) => fetchOwn.__executeServer(opts));
var fetchOwn = createServerFn({ method: "POST" }).inputValidator((data) => data ?? {}).handler(fetchOwn_createServerFn_handler, async ({ data }) => {
	const { lookupOwn } = await import("./rsvp.server-CeiC8-tp.mjs");
	return lookupOwn(data);
});
var adminSession_createServerFn_handler = createServerRpc({
	id: "37108608036e714dd59eebd708ac53730586605ff2619b06637d13dc174189fc",
	name: "adminSession",
	filename: "src/lib/rsvp.functions.ts"
}, (opts) => adminSession.__executeServer(opts));
var adminSession = createServerFn({ method: "GET" }).handler(adminSession_createServerFn_handler, async () => {
	const { currentAdmin } = await import("./rsvp.server-CeiC8-tp.mjs");
	const admin = await currentAdmin();
	return {
		authenticated: Boolean(admin),
		username: admin?.username ?? ""
	};
});
var adminLogin_createServerFn_handler = createServerRpc({
	id: "31efafa198a3111bd42c3ccd7e8dd5224aea34b89219310dc02d9c2cb11a7e36",
	name: "adminLogin",
	filename: "src/lib/rsvp.functions.ts"
}, (opts) => adminLogin.__executeServer(opts));
var adminLogin = createServerFn({ method: "POST" }).inputValidator((data) => ({
	username: typeof data?.username === "string" ? data.username : "",
	password: typeof data?.password === "string" ? data.password : ""
})).handler(adminLogin_createServerFn_handler, async ({ data }) => {
	const { loginAdmin } = await import("./rsvp.server-CeiC8-tp.mjs");
	return loginAdmin(data.username, data.password);
});
var adminLogout_createServerFn_handler = createServerRpc({
	id: "08523f82e89e185f81a954335e1ed12953b8bd82e5cc3eeb26e664693b34b780",
	name: "adminLogout",
	filename: "src/lib/rsvp.functions.ts"
}, (opts) => adminLogout.__executeServer(opts));
var adminLogout = createServerFn({ method: "POST" }).handler(adminLogout_createServerFn_handler, async () => {
	const { logoutAdmin } = await import("./rsvp.server-CeiC8-tp.mjs");
	return logoutAdmin();
});
var changePassword_createServerFn_handler = createServerRpc({
	id: "b73dab6850a7a6c18996bc85ec1f43902782b7d5afc3dd033eff6bfaa655692f",
	name: "changePassword",
	filename: "src/lib/rsvp.functions.ts"
}, (opts) => changePassword.__executeServer(opts));
var changePassword = createServerFn({ method: "POST" }).inputValidator((data) => ({
	currentPassword: typeof data?.currentPassword === "string" ? data.currentPassword : "",
	nextPassword: typeof data?.nextPassword === "string" ? data.nextPassword : ""
})).handler(changePassword_createServerFn_handler, async ({ data }) => {
	const { changeAdminPassword } = await import("./rsvp.server-CeiC8-tp.mjs");
	return changeAdminPassword(data.currentPassword, data.nextPassword);
});
var loadDashboard_createServerFn_handler = createServerRpc({
	id: "baa2765ea17ace67f2081cc1eef976a0da619fd35df981c99690a241547de31c",
	name: "loadDashboard",
	filename: "src/lib/rsvp.functions.ts"
}, (opts) => loadDashboard.__executeServer(opts));
var loadDashboard = createServerFn({ method: "GET" }).handler(loadDashboard_createServerFn_handler, async () => {
	const { adminOverview } = await import("./rsvp.server-CeiC8-tp.mjs");
	return adminOverview();
});
var updateRegistration_createServerFn_handler = createServerRpc({
	id: "704c65d56af84c9d1708cc1a04b376c508b93a7062c7336a2093419715f76288",
	name: "updateRegistration",
	filename: "src/lib/rsvp.functions.ts"
}, (opts) => updateRegistration.__executeServer(opts));
var updateRegistration = createServerFn({ method: "POST" }).inputValidator((data) => data).handler(updateRegistration_createServerFn_handler, async ({ data }) => {
	const { adminUpdate } = await import("./rsvp.server-CeiC8-tp.mjs");
	return adminUpdate(data);
});
var deleteRegistration_createServerFn_handler = createServerRpc({
	id: "b73657b94ea52d246932f39252ce8a5a6fe17fb9380f939bf53c495ce193ba27",
	name: "deleteRegistration",
	filename: "src/lib/rsvp.functions.ts"
}, (opts) => deleteRegistration.__executeServer(opts));
var deleteRegistration = createServerFn({ method: "POST" }).inputValidator((data) => ({ id: typeof data?.id === "string" ? data.id : "" })).handler(deleteRegistration_createServerFn_handler, async ({ data }) => {
	const { adminRemove } = await import("./rsvp.server-CeiC8-tp.mjs");
	return adminRemove(data);
});
//#endregion
export { adminLogin_createServerFn_handler, adminLogout_createServerFn_handler, adminSession_createServerFn_handler, changePassword_createServerFn_handler, deleteRegistration_createServerFn_handler, fetchOwn_createServerFn_handler, loadDashboard_createServerFn_handler, submitRegistration_createServerFn_handler, updateRegistration_createServerFn_handler };
