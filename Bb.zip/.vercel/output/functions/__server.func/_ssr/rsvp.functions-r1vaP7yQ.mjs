import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rsvp.functions-r1vaP7yQ.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var submitRegistration = createServerFn({ method: "POST" }).inputValidator((data) => data).handler(createSsrRpc("3b15b66090a2feafa93c584cff65bbc98e5e56dc7c0960ad1bbe5ca6283f3816"));
var fetchOwn = createServerFn({ method: "POST" }).inputValidator((data) => data ?? {}).handler(createSsrRpc("efc40a0d76a9ee4373c9f666df4dd82b1e2aecc5df597bcd4ae70b499cca0c21"));
var adminSession = createServerFn({ method: "GET" }).handler(createSsrRpc("37108608036e714dd59eebd708ac53730586605ff2619b06637d13dc174189fc"));
var adminLogin = createServerFn({ method: "POST" }).inputValidator((data) => ({
	username: typeof data?.username === "string" ? data.username : "",
	password: typeof data?.password === "string" ? data.password : ""
})).handler(createSsrRpc("31efafa198a3111bd42c3ccd7e8dd5224aea34b89219310dc02d9c2cb11a7e36"));
var adminLogout = createServerFn({ method: "POST" }).handler(createSsrRpc("08523f82e89e185f81a954335e1ed12953b8bd82e5cc3eeb26e664693b34b780"));
var changePassword = createServerFn({ method: "POST" }).inputValidator((data) => ({
	currentPassword: typeof data?.currentPassword === "string" ? data.currentPassword : "",
	nextPassword: typeof data?.nextPassword === "string" ? data.nextPassword : ""
})).handler(createSsrRpc("b73dab6850a7a6c18996bc85ec1f43902782b7d5afc3dd033eff6bfaa655692f"));
var loadDashboard = createServerFn({ method: "GET" }).handler(createSsrRpc("baa2765ea17ace67f2081cc1eef976a0da619fd35df981c99690a241547de31c"));
var updateRegistration = createServerFn({ method: "POST" }).inputValidator((data) => data).handler(createSsrRpc("704c65d56af84c9d1708cc1a04b376c508b93a7062c7336a2093419715f76288"));
var deleteRegistration = createServerFn({ method: "POST" }).inputValidator((data) => ({ id: typeof data?.id === "string" ? data.id : "" })).handler(createSsrRpc("b73657b94ea52d246932f39252ce8a5a6fe17fb9380f939bf53c495ce193ba27"));
//#endregion
export { deleteRegistration as a, submitRegistration as c, changePassword as i, updateRegistration as l, adminLogout as n, fetchOwn as o, adminSession as r, loadDashboard as s, adminLogin as t };
