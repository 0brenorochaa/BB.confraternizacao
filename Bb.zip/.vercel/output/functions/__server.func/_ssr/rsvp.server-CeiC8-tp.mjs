import { a as getCookie, i as deleteCookie$1, o as setCookie$1 } from "./ssr.mjs";
import { n as SUCCESS_MESSAGE, o as normalizeName, r as coerceInput, s as validateRsvp } from "./rsvp-model-PNZCC2kM.mjs";
import { createHash, randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
//#region node_modules/.nitro/vite/services/ssr/assets/rsvp.server-CeiC8-tp.js
var _0002_confraternizacao_default = "-- BB Confraternização 2026 — confirmações e acesso da organização.\n-- A senha inicial não fica neste arquivo: apenas o hash scrypt (salt:hash).\n\ncreate table if not exists admins (\n  id text primary key,\n  username text not null unique,\n  password_hash text not null,\n  updated_at timestamptz not null default now()\n);\n\ninsert into admins (id, username, password_hash)\nvalues (\n  'organizer',\n  'Participantesbb26',\n  '31177d1020804683558d3c8b3a27595d:0c23f4e4e266c45e2dd09cfbc3ebf28103c73db8666023194c7d5e1778d04677f7865f35f97f75dddae619d96c883ded785c1af27e0a501455ff20088d24ff55'\n)\non conflict (username) do nothing;\n\ncreate table if not exists admin_sessions (\n  token_hash text primary key,\n  admin_id text not null references admins (id) on delete cascade,\n  expires_at timestamptz not null,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists login_attempts (\n  id serial primary key,\n  success boolean not null,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists rsvps (\n  id text primary key,\n  full_name text not null,\n  name_key text not null unique,\n  attending boolean not null,\n  has_companion boolean not null default false,\n  companion_name text not null default '',\n  companion_relation text not null default '',\n  companion_relation_note text not null default '',\n  correction_hash text not null,\n  created_at timestamptz not null default now(),\n  updated_at timestamptz not null default now(),\n  constraint rsvps_companion_chk check (\n    (attending = false and has_companion = false)\n    or (attending = true and has_companion = false)\n    or (\n      attending = true\n      and has_companion = true\n      and length(companion_name) > 0\n      and length(companion_relation) > 0\n    )\n  )\n);\n\ncreate index if not exists rsvps_attending_idx on rsvps (attending);\ncreate index if not exists rsvps_correction_hash_idx on rsvps (correction_hash);\ncreate index if not exists admin_sessions_expires_idx on admin_sessions (expires_at);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_confraternizacao.sql": _0002_confraternizacao_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
function env(key) {
	return process.env[key]?.trim() || void 0;
}
/**
* Workspace preview vs deployed app. The deployer writes GROK_PROJECT_ID on
* every publish; the sandbox preview never has it. Single source of truth for
* the split — gate audience, gate endpoints and connector-token semantics all
* key off this predicate.
*/
function isWorkspacePreview() {
	return !env("GROK_PROJECT_ID");
}
var scryptAsync = promisify(scrypt);
var KEY_LEN = 64;
/** scrypt salt:hash of the initial organizer password. Plaintext is not stored. */
var INITIAL_PASSWORD_HASH = "31177d1020804683558d3c8b3a27595d:0c23f4e4e266c45e2dd09cfbc3ebf28103c73db8666023194c7d5e1778d04677f7865f35f97f75dddae619d96c883ded785c1af27e0a501455ff20088d24ff55";
var INITIAL_USERNAME = "Participantesbb26";
async function hashPassword(password) {
	const salt = randomBytes(16);
	const derived = await scryptAsync(password, salt, KEY_LEN);
	return `${salt.toString("hex")}:${derived.toString("hex")}`;
}
async function verifyPassword(password, stored) {
	const [saltHex, hashHex] = stored.split(":");
	if (!saltHex || !hashHex || saltHex.length < 16 || hashHex.length < 32) return false;
	let salt;
	let expected;
	try {
		salt = Buffer.from(saltHex, "hex");
		expected = Buffer.from(hashHex, "hex");
	} catch {
		return false;
	}
	if (salt.length === 0 || expected.length === 0) return false;
	const derived = await scryptAsync(password, salt, expected.length);
	if (derived.length !== expected.length) return false;
	return timingSafeEqual(derived, expected);
}
function sha256(value) {
	return createHash("sha256").update(value).digest("hex");
}
function newSecret(bytes = 32) {
	return randomBytes(bytes).toString("hex");
}
var ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function newCorrectionCode() {
	const bytes = randomBytes(10);
	let raw = "";
	for (let i = 0; i < 10; i += 1) raw += ALPHABET[bytes[i] % 32];
	return raw;
}
function normalizeCode(code) {
	return code.toUpperCase().replace(/[^A-Z0-9]/g, "");
}
function formatCode(raw) {
	const normalized = normalizeCode(raw);
	if (normalized.length !== 10) return normalized;
	return `${normalized.slice(0, 5)}-${normalized.slice(5)}`;
}
var ADMIN_COOKIE = "bb26_admin";
var TICKET_COOKIE = "bb26_ticket";
var SESSION_SECONDS = 43200;
var TICKET_SECONDS = 15552e3;
function cookieBase() {
	return {
		httpOnly: true,
		sameSite: "lax",
		path: "/",
		secure: !isWorkspacePreview()
	};
}
function toIso(value) {
	if (value instanceof Date) return value.toISOString();
	const parsed = new Date(String(value));
	if (Number.isNaN(parsed.getTime())) return (/* @__PURE__ */ new Date(0)).toISOString();
	return parsed.toISOString();
}
function num(value) {
	const parsed = typeof value === "number" ? value : Number(value);
	return Number.isFinite(parsed) ? parsed : 0;
}
function mapRow(row) {
	return {
		id: row.id,
		fullName: row.full_name,
		attending: row.attending === true,
		hasCompanion: row.has_companion === true,
		companionName: row.companion_name ?? "",
		companionRelation: row.companion_relation ?? "",
		companionRelationNote: row.companion_relation_note ?? "",
		createdAt: toIso(row.created_at),
		updatedAt: toIso(row.updated_at)
	};
}
async function ensureAdmin(sql) {
	if ((await sql`select id from admins limit 1`).length > 0) return;
	await sql`
    insert into admins (id, username, password_hash)
    values ('organizer', ${INITIAL_USERNAME}, ${INITIAL_PASSWORD_HASH})
  `;
}
async function findByCode(sql, code) {
	const normalized = normalizeCode(code);
	if (normalized.length < 8) return null;
	return (await sql`
    select * from rsvps where correction_hash = ${sha256(normalized)} limit 1
  `)[0] ?? null;
}
async function currentAdmin() {
	const token = getCookie(ADMIN_COOKIE);
	if (!token) return null;
	return (await (await getSql())`
    select a.id, a.username
    from admin_sessions s
    join admins a on a.id = s.admin_id
    where s.token_hash = ${sha256(token)}
      and s.expires_at > now()
    limit 1
  `)[0] ?? null;
}
async function requireAdmin() {
	const admin = await currentAdmin();
	if (!admin) return null;
	return admin;
}
async function loginAdmin(username, password) {
	const sql = await getSql();
	await ensureAdmin(sql);
	await sql`delete from login_attempts where created_at < now() - interval '1 day'`;
	if (num((await sql`
    select count(*)::int as n
    from login_attempts
    where success = false
      and created_at > now() - interval '15 minutes'
  `)[0]?.n) >= 8) return {
		ok: false,
		error: "Muitas tentativas. Aguarde alguns minutos e tente de novo."
	};
	const row = (await sql`
    select id, username, password_hash from admins where username = ${username.trim()} limit 1
  `)[0];
	const valid = await verifyPassword(password, row?.password_hash ?? "31177d1020804683558d3c8b3a27595d:0c23f4e4e266c45e2dd09cfbc3ebf28103c73db8666023194c7d5e1778d04677f7865f35f97f75dddae619d96c883ded785c1af27e0a501455ff20088d24ff55");
	if (!row || !valid) {
		await sql`insert into login_attempts (success) values (false)`;
		return {
			ok: false,
			error: "Usuário ou senha incorretos."
		};
	}
	await sql`insert into login_attempts (success) values (true)`;
	await sql`delete from admin_sessions where expires_at < now()`;
	const token = newSecret();
	const expires = new Date(Date.now() + SESSION_SECONDS * 1e3).toISOString();
	await sql`
    insert into admin_sessions (token_hash, admin_id, expires_at)
    values (${sha256(token)}, ${row.id}, ${expires})
  `;
	setCookie$1(ADMIN_COOKIE, token, {
		...cookieBase(),
		maxAge: SESSION_SECONDS
	});
	return {
		ok: true,
		username: row.username
	};
}
async function logoutAdmin() {
	const token = getCookie(ADMIN_COOKIE);
	if (token) await (await getSql())`delete from admin_sessions where token_hash = ${sha256(token)}`;
	deleteCookie$1(ADMIN_COOKIE, cookieBase());
	return { ok: true };
}
async function changeAdminPassword(currentPassword, nextPassword) {
	const admin = await requireAdmin();
	if (!admin) return {
		ok: false,
		error: "Sessão expirada. Entre novamente."
	};
	if (nextPassword.length < 8) return {
		ok: false,
		error: "A nova senha precisa ter pelo menos 8 caracteres."
	};
	if (nextPassword.length > 72) return {
		ok: false,
		error: "A nova senha está longa demais."
	};
	if (nextPassword === currentPassword) return {
		ok: false,
		error: "Escolha uma senha diferente da atual."
	};
	const sql = await getSql();
	const stored = (await sql`
    select password_hash from admins where id = ${admin.id} limit 1
  `)[0]?.password_hash;
	if (!stored || !await verifyPassword(currentPassword, stored)) return {
		ok: false,
		error: "A senha atual não confere."
	};
	await sql`
    update admins
    set password_hash = ${await hashPassword(nextPassword)}, updated_at = now()
    where id = ${admin.id}
  `;
	const token = getCookie(ADMIN_COOKIE);
	if (token) await sql`
      delete from admin_sessions
      where admin_id = ${admin.id} and token_hash <> ${sha256(token)}
    `;
	return { ok: true };
}
function rememberTicket(code) {
	const normalized = normalizeCode(code);
	if (!normalized) return;
	setCookie$1(TICKET_COOKIE, normalized, {
		...cookieBase(),
		maxAge: TICKET_SECONDS
	});
}
async function writeRow(sql, id, value) {
	await sql`
    update rsvps set
      full_name = ${value.fullName},
      name_key = ${normalizeName(value.fullName)},
      attending = ${value.attending},
      has_companion = ${value.hasCompanion},
      companion_name = ${value.companionName},
      companion_relation = ${value.companionRelation},
      companion_relation_note = ${value.companionRelationNote},
      updated_at = now()
    where id = ${id}
  `;
}
async function submitRegistration(raw) {
	const parsed = validateRsvp(coerceInput(raw));
	if (!parsed.ok) return parsed;
	const value = parsed.value;
	const sql = await getSql();
	const nameKey = normalizeName(value.fullName);
	const explicit = normalizeCode(value.correctionCode);
	const cookieCode = normalizeCode(getCookie(TICKET_COOKIE) ?? "");
	let owned = null;
	let ownedCode = "";
	if (explicit) {
		owned = await findByCode(sql, explicit);
		if (!owned) return {
			ok: false,
			error: "Código de correção não encontrado. Confira os caracteres e tente de novo."
		};
		ownedCode = explicit;
	} else if (cookieCode) {
		const fromCookie = await findByCode(sql, cookieCode);
		if (fromCookie && fromCookie.name_key === nameKey) {
			owned = fromCookie;
			ownedCode = cookieCode;
		}
	}
	if (owned) {
		if ((await sql`
      select id from rsvps where name_key = ${nameKey} and id <> ${owned.id} limit 1
    `).length > 0) return {
			ok: false,
			error: "Este nome já está em outra confirmação."
		};
		await writeRow(sql, owned.id, value);
		rememberTicket(ownedCode);
		const fresh = await sql`select * from rsvps where id = ${owned.id} limit 1`;
		return {
			ok: true,
			created: false,
			code: formatCode(ownedCode),
			message: SUCCESS_MESSAGE,
			rsvp: mapRow(fresh[0] ?? owned)
		};
	}
	if ((await sql`
    select id from rsvps where name_key = ${nameKey} limit 1
  `).length > 0) return {
		ok: false,
		error: "Já existe uma confirmação com este nome. Use o código de correção para atualizar somente a sua resposta."
	};
	const code = newCorrectionCode();
	const id = crypto.randomUUID();
	try {
		await sql`
      insert into rsvps (
        id, full_name, name_key, attending, has_companion, companion_name,
        companion_relation, companion_relation_note, correction_hash
      ) values (
        ${id},
        ${value.fullName},
        ${nameKey},
        ${value.attending},
        ${value.hasCompanion},
        ${value.companionName},
        ${value.companionRelation},
        ${value.companionRelationNote},
        ${sha256(code)}
      )
    `;
	} catch (error) {
		const message = error instanceof Error ? error.message.toLowerCase() : "";
		if (message.includes("unique") || message.includes("23505")) return {
			ok: false,
			error: "Já existe uma confirmação com este nome. Use o código de correção para atualizar somente a sua resposta."
		};
		throw error;
	}
	rememberTicket(code);
	const fresh = await sql`select * from rsvps where id = ${id} limit 1`;
	if (!fresh[0]) throw new Error("Não foi possível ler a confirmação recém-salva.");
	return {
		ok: true,
		created: true,
		code: formatCode(code),
		message: SUCCESS_MESSAGE,
		rsvp: mapRow(fresh[0])
	};
}
async function lookupOwn(raw) {
	const record = raw && typeof raw === "object" ? raw : {};
	const typed = typeof record.code === "string" ? record.code : "";
	const sql = await getSql();
	const explicit = normalizeCode(typed);
	const cookieCode = normalizeCode(getCookie(TICKET_COOKIE) ?? "");
	if (explicit) {
		const row = await findByCode(sql, explicit);
		if (!row) return {
			ok: false,
			error: "Código não encontrado. Confira e tente de novo."
		};
		rememberTicket(explicit);
		return {
			ok: true,
			rsvp: mapRow(row),
			code: formatCode(explicit)
		};
	}
	if (cookieCode) {
		const row = await findByCode(sql, cookieCode);
		if (row) return {
			ok: true,
			rsvp: mapRow(row),
			code: formatCode(cookieCode)
		};
	}
	return {
		ok: true,
		rsvp: null,
		code: ""
	};
}
async function adminOverview() {
	const admin = await requireAdmin();
	if (!admin) return {
		ok: false,
		error: "Não autorizado."
	};
	const sql = await getSql();
	const statsRow = (await sql`
    select
      count(*)::int as registered,
      count(*) filter (where attending)::int as attending,
      count(*) filter (where not attending)::int as absent,
      count(*) filter (where attending and has_companion)::int as companions
    from rsvps
  `)[0];
	const attending = num(statsRow?.attending);
	const companions = num(statsRow?.companions);
	const rows = await sql`select * from rsvps order by created_at desc, full_name asc`;
	return {
		ok: true,
		username: admin.username,
		stats: {
			registered: num(statsRow?.registered),
			attending,
			absent: num(statsRow?.absent),
			companions,
			confirmedPeople: attending + companions
		},
		rows: rows.map(mapRow)
	};
}
async function adminUpdate(raw) {
	if (!await requireAdmin()) return {
		ok: false,
		error: "Não autorizado."
	};
	const record = raw && typeof raw === "object" ? raw : {};
	const id = typeof record.id === "string" ? record.id : "";
	if (!id) return {
		ok: false,
		error: "Registro inválido."
	};
	const parsed = validateRsvp(coerceInput(raw));
	if (!parsed.ok) return parsed;
	const value = parsed.value;
	const sql = await getSql();
	if ((await sql`
    select id from rsvps where name_key = ${normalizeName(value.fullName)} and id <> ${id} limit 1
  `).length > 0) return {
		ok: false,
		error: "Já existe outro participante com este nome."
	};
	if ((await sql`select id from rsvps where id = ${id} limit 1`).length === 0) return {
		ok: false,
		error: "Registro não encontrado."
	};
	await writeRow(sql, id, value);
	return { ok: true };
}
async function adminRemove(raw) {
	if (!await requireAdmin()) return {
		ok: false,
		error: "Não autorizado."
	};
	const record = raw && typeof raw === "object" ? raw : {};
	const id = typeof record.id === "string" ? record.id : "";
	if (!id) return {
		ok: false,
		error: "Registro inválido."
	};
	if ((await (await getSql())`delete from rsvps where id = ${id} returning id`).length === 0) return {
		ok: false,
		error: "Registro não encontrado."
	};
	return { ok: true };
}
//#endregion
export { adminOverview, adminRemove, adminUpdate, changeAdminPassword, currentAdmin, loginAdmin, logoutAdmin, lookupOwn, submitRegistration };
