import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-6J1SPnMg.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var tap = "transition-transform duration-150 ease-out active:not-disabled:scale-[0.96]";
function Button({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex h-12 items-center justify-center gap-2 rounded-full px-5 text-sm font-semibold tracking-wide uppercase disabled:opacity-55", tap, variant === "primary" && "bg-navy text-paper", variant === "gold" && "bg-gold text-navy", variant === "ghost" && "bg-transparent text-paper", variant === "quiet" && "bg-card text-navy shadow-field", className),
		...props
	});
}
function TextField({ label, hint, className, ...props }) {
	const id = props.id ?? props.name;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-medium text-ink",
		htmlFor: id,
		children: [
			label,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				className: cn("mt-2 h-12 w-full rounded-xl bg-card px-3 text-base font-normal text-ink shadow-field placeholder:text-muted", className),
				...props
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-xs font-normal text-muted",
				children: hint
			}) : null
		]
	});
}
function SelectField({ label, children, ...props }) {
	const id = props.id ?? props.name;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-medium text-ink",
		htmlFor: id,
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			id,
			className: "mt-2 h-12 w-full rounded-xl bg-card px-3 text-base font-normal text-ink shadow-field",
			...props,
			children
		})]
	});
}
function Alert({ tone = "error", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: tone === "error" ? "alert" : "status",
		className: cn("rounded-xl px-3 py-3 text-sm", tone === "error" ? "bg-navy text-paper" : "bg-gold/20 text-navy"),
		children
	});
}
//#endregion
export { cn as a, TextField as i, Button as n, SelectField as r, Alert as t };
