//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CEBWMxIW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/corrigir",
			"/admin/painel",
			"/admin/"
		],
		preloads: ["/assets/index-CVqUdI2x.js", "/assets/rsvp.functions-BEhyOlKZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CVqUdI2x.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-UYsilwG7.js",
			"/assets/rsvp-form-Dz9N8p7z.js",
			"/assets/ui-C9ZAJ_wB.js"
		]
	},
	"/corrigir": {
		filePath: "/workspace/src/routes/corrigir.tsx",
		children: void 0,
		preloads: [
			"/assets/corrigir-Cyfdy8Gs.js",
			"/assets/rsvp-form-Dz9N8p7z.js",
			"/assets/ui-C9ZAJ_wB.js"
		]
	},
	"/admin/painel": {
		filePath: "/workspace/src/routes/admin/painel.tsx",
		children: void 0,
		preloads: [
			"/assets/painel-CiKwILC1.js",
			"/assets/rsvp-form-Dz9N8p7z.js",
			"/assets/ui-C9ZAJ_wB.js"
		]
	},
	"/admin/": {
		filePath: "/workspace/src/routes/admin/index.tsx",
		children: void 0,
		preloads: ["/assets/admin-BIS9BYeN.js", "/assets/ui-C9ZAJ_wB.js"]
	}
} });
//#endregion
export { tsrStartManifest };
